let id = 1;
const products = [
  { id: 1, name: "iphone", price: 10000 },
  { id: 2, name: "iphone", price: 10000 },
  { id: 3, name: "iphone", price: 10000 },
];

export const fetchAllProducts = () => {
  return products;
};
