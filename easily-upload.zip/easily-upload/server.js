import { server } from "./index.js";

server.listen(3200, () => {
  console.log("Server is running on port 3200");
});
